SELECT * FROM acesso a
LIMIT 1
ORDER BY a.data_solicitacao DESC

/*
SELECT * FROM acesso a 
WHERE a.data_solicitacao >= '2026-05-21'
ORDER BY  a.nome ASC, a.data_solicitacao DESC
-- ==========================================
*/

ALTER TABLE acesso ADD COLUMN cnh TEXT;
ALTER TABLE acesso ADD COLUMN cat_habilitacao TEXT;
ALTER TABLE acesso ADD COLUMN validade_cnh TEXT;


SELECT * FROM users u
UPDATE users SET email = "helder.martins"
where id = 2

SELECT * FROM avaria_orcamentos
SELECT * FROM inicio_avaria
SELECT * FROM avaria_motorista


/*
INSERT INTO acesso (ticket, nome, doc_nacional, numero_doc, empresa, data_do_acesso, qtd_dias, visita_a, com_veiculo, placa, tipo_veiculo, justificativa, portoes, autorizado, data_solicitacao, data_limite, user_id) VALUES ('37', 'ANDREA ALMEIDA LOPES DE DEUS', 'CPF', '117.742.377-41', 'VISITA CLIENTE', '2026-05-27', 1, 'TECON SALVADOR', 0, NULL, NULL, 'VISITANTE', '2', 'SOLICITADO', '2026-05-21', '2026-05-27', 1);
INSERT INTO acesso (ticket, nome, doc_nacional, numero_doc, empresa, data_do_acesso, qtd_dias, visita_a, com_veiculo, placa, tipo_veiculo, justificativa, portoes, autorizado, data_solicitacao, data_limite, user_id) VALUES ('38', 'JAQUELINE DITTRICH TREVISAN', 'CPF', '080.630.699-86', 'VISITA CLIENTE', '2026-05-27', 1, 'TECON SALVADOR', 0, NULL, NULL, 'VISITANTE', '2', 'SOLICITADO', '2026-05-21', '2026-05-27', 1);
INSERT INTO acesso (ticket, nome, doc_nacional, numero_doc, empresa, data_do_acesso, qtd_dias, visita_a, com_veiculo, placa, tipo_veiculo, justificativa, portoes, autorizado, data_solicitacao, data_limite, user_id) VALUES ('87', 'AMERICO SIMOES OLIVEIRA', 'CPF', '021.992.875-48', 'VINHEDOS TRANSPORTES', '2026-05-28', 5, 'ACESSO AO PORTO', 1, 'JAQ5E57', 'DE CARGA', 'ENTREGA DE MATERIAL', '3', 'SOLICITADO', '2026-05-21', '2026-05-29', 1);
INSERT INTO acesso (ticket, nome, doc_nacional, numero_doc, empresa, data_do_acesso, qtd_dias, visita_a, com_veiculo, placa, tipo_veiculo, justificativa, portoes, autorizado, data_solicitacao, data_limite, user_id) VALUES ('87', 'AMERICO SIMOES OLIVEIRA', 'CPF', '021.992.875-48', 'VINHEDOS TRANSPORTES', '2026-05-29', 5, 'ACESSO AO PORTO', 1, 'JAQ5E57', 'DE CARGA', 'ENTREGA DE MATERIAL', '3', 'SOLICITADO', '2026-05-21', '2026-05-29', 1);
*/

ALTER TABLE acesso RENAME COLUMN validade_cnh TO data_validade_cnh;