import 'express-session';

declare module 'express-session' {
    interface SessionData {
        userId: number;
        userName: string;
        isAdmin: boolean;
        modulosPermitidos: string[];
    }
}