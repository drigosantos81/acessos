SELECT * FROM sessions a
LIMIT 1
ORDER BY a.data_solicitacao DESC